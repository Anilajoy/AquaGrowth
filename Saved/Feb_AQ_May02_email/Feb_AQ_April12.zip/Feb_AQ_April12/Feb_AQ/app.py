from flask import Flask, render_template, request, redirect, url_for
import sqlite3
import pandas as pd
import pickle
from flask import jsonify
from datetime import datetime, timezone, timedelta

app = Flask(__name__, static_url_path='/static')


# Load the trained model
with open("DiameterXGBoostV0.pkl", "rb") as model_file:
    model = pickle.load(model_file)


# Define the feature names used during training XGboost
feature_names = ['Leaves', 'Height', 'Ambient_Temp', 'Humidity']



@app.route('/')
def home():
    return render_template('index.html')



@app.route("/predict", methods=["POST"])
def predict():
    if request.method == "POST":
        leaves = int(request.form["leaves"])
        height = float(request.form["height"])
        temperature= float(request.form["temperature"])
        humidity = float(request.form["humidity"])
# Create a DataFrame with the correct feature names
        input_data = pd.DataFrame([[leaves, height, temperature, humidity]], columns=feature_names)
            
            # Perform the prediction using the model
        diameter = model.predict(input_data)
        predicted_diameter = float(diameter[0])
        
        # Return predicted diameter as JSON response
       # return jsonify({'diameter': predicted_diameter})
        #return jsonify({'diameter': diameter[0]})
        return render_template("predict_diameter.html", diameter=diameter[0])


@app.route('/save_option', methods=['POST'])
def save_option():
    # Connect to the SQLite database
    conn = sqlite3.connect('studyDemo.db', check_same_thread=False)
    cursor = conn.cursor()
    
    # Retrieve the selected option from the form
    selected_option = request.form.get('option')
    
    # Insert the selected option into the database
    query = "INSERT INTO selectDHprediction (DHselection) VALUES (?)"
    values = (selected_option,)
    cursor.execute(query, values)
    
    # Commit the transaction and close the connection
    conn.commit()
    conn.close()
    
    # Redirect back to the home page or wherever you want after insertion
    return redirect(url_for('home'))

@app.route('/prediction_diameter')
def prediction_diameter():
    return render_template('predict_diameter.html')


@app.route('/prediction_height')
def prediction_height():
    return render_template('predict_height.html')

@app.route('/prediction_water_ph')
def prediction_water_ph():
    return render_template('water_pH.html')

@app.route('/prediction_water_temperature')
def prediction_water_temperature():
    return render_template('water_temperature.html')

# Define routes for other prediction options similarly

if __name__ == '__main__':
    app.run(debug=True)
